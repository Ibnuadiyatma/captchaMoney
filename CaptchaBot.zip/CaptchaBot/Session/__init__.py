# empty package initializer for Session
